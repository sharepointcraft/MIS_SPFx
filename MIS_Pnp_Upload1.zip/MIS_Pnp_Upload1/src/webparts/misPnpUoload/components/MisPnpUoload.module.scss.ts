/* tslint:disable */
require("./MisPnpUoload.module.css");
const styles = {

};

export default styles;
/* tslint:enable */