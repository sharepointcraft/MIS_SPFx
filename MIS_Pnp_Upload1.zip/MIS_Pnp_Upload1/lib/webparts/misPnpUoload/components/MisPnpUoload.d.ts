import * as React from "react";
import type { IMisPnpUoloadProps } from "./IMisPnpUoloadProps";
import "./MisPnpUoload.module.scss";
interface ITableData {
    "NDC Code": string;
    Plant: string;
    Dosage_form: string;
    Material_code: number;
    Description: string;
    Product: string;
    Strength: number;
    Pack_size: number;
    RMC: string;
    PMC: string;
    Consumables: string;
    Conversion_cost: string;
    Acquisition_Cost_CMO: string;
    Interest_on_Wc: string;
    COP: string;
    Freight_DDP_Sea: string;
    COGS: string;
    Updated_Date: string;
    Remarks_on_Changes: string;
}
interface IAttachment {
    file: File;
    ndcCode: string;
}
export default class MisPnpUpload extends React.Component<IMisPnpUoloadProps, {
    filePickerResult: File[];
    tableData: ITableData[];
    attachments: IAttachment[];
    fileName: string;
    isSubmitDisabled: boolean;
    loading: boolean;
}> {
    constructor(props: IMisPnpUoloadProps);
    componentDidMount(): void;
    render(): React.ReactElement<IMisPnpUoloadProps>;
    private fileInput;
    private _triggerFileInput;
    private _onFileSelected;
    private _parseCSV;
    private _parseExcel;
    private _convertExcelDate;
    private _renderTable;
    private _handleFileChange;
    private _handleCancel;
    private _handleSubmit;
}
export {};
//# sourceMappingURL=MisPnpUoload.d.ts.map