declare const styles: {};
export default styles;
//# sourceMappingURL=MisPnpUoload.module.scss.d.ts.map